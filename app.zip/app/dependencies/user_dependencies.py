from fastapi import HTTPException, status, Depends
from sqlalchemy.orm import Session
from app.database.connection import SessionLocal  # Importamos la fábrica local
from app.models.user_model import Usuario

# 1. La función que abre y cierra la sesión de la DB (Nuestra llave del ciclo de vida)
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 2. Dependencia para buscar un usuario por ID en la DB real o disparar 404
def get_user_or_404(user_id: int, db: Session = Depends(get_db)) -> Usuario:
    # Hacemos un SELECT * FROM usuarios WHERE id = user_id LIMIT 1
    usuario = db.query(Usuario).filter(Usuario.id == user_id).first()
    
    if not usuario:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, 
            detail="El usuario que buscas no existe."
        )
    return usuario

# 3. Dependencia para verificar si un correo ya está en uso por otro usuario
def verificar_correo_duplicado(email: str, db: Session, excluir_id: int = None):
    # Buscamos si existe algún usuario con ese correo
    query = db.query(Usuario).filter(Usuario.email == email)
    
    # Si estamos editando (PUT/PATCH), le decimos que ignore el ID del mismo usuario
    if excluir_id is not None:
        query = query.filter(Usuario.id != excluir_id)
        
    usuario_existente = query.first()
    
    if usuario_existente:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="Ese correo ya existe, intenta con otro."
        )